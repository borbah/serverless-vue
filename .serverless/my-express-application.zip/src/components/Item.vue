<template>

</template>
<script>
  export default {
    name: 'Item',
  };
</script>
<style lang="scss" scoped>

</style>