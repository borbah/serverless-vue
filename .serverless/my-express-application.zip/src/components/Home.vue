<template>
  <h1>Dupa</h1>
</template>
<script>
  export default {
    name: 'Home',
  };
</script>
<style lang="scss" scoped>
  h1 {
    color: red;
  }
</style>