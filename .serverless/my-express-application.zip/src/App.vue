<template>
  <h1>hello</h1>
</template>
<script>
  export default {
    name: 'App',
  };
</script>
<style lang="scss" scoped>

</style>